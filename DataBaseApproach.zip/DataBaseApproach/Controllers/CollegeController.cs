﻿
using DataBaseApproach.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DataBaseApproach.Controllers
{
    
    public class CollegeController : Controller
    {
        CollegeContext CollegeContext = new CollegeContext();
        // GET: College
        public ActionResult Index()
        {

            return View(CollegeContext.College_172477.ToList());
        }
        [HttpGet]
        public ActionResult ADD()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ADD(College_172477 college_172477)
        {
            if (ModelState.IsValid)
            {
                CollegeContext.College_172477.Add(college_172477);
                CollegeContext.SaveChanges();

                return RedirectToAction("Index", CollegeContext.College_172477.ToList());
            }
          else
            {
                return View();
            }
              
        }
        [HttpGet]
        public ActionResult Update(int? id)
       {
            var stud = CollegeContext.College_172477.Where(e => e.HallTicketNumber == id).FirstOrDefault();
            return View(stud);
        }

        [HttpPost]
        public ActionResult Update(College_172477 college_172477)
        {
            if (ModelState.IsValid)
            {
                var stud = CollegeContext.College_172477.Single(e => e.HallTicketNumber == college_172477.HallTicketNumber);
                //stud.HallTicketNumber = college_172477.HallTicketNumber;
                stud.StudentName = college_172477.StudentName;
                stud.Age = college_172477.Age;
                stud.Gender = college_172477.Gender;
                stud.DateOFBirth = college_172477.DateOFBirth;
                stud.Skills = college_172477.Skills;
                stud.EmailID = college_172477.EmailID;
                stud.PreferedSubject = college_172477.PreferedSubject;
                CollegeContext.SaveChanges();
                return RedirectToAction("Index", CollegeContext.College_172477.ToList());
            }
            else
            {
                return View(college_172477);
            }            
                    
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            College_172477 stud = CollegeContext.College_172477.Single(e => e.HallTicketNumber== id);
            CollegeContext.College_172477.Remove(stud);
            CollegeContext.SaveChanges();
            Response.Write("Record Deleted");

            return RedirectToAction("Index", CollegeContext.College_172477.ToList());

        }
        public ActionResult Search(int id)
        {
            var stud = CollegeContext.College_172477.Single(e => e.HallTicketNumber == id);
            return View(stud);
            
        }
        [HttpPost]
        public ActionResult Show(College_172477 college_172477)
        {
            var d = (from l in CollegeContext.College_172477 where l.HallTicketNumber == college_172477.HallTicketNumber select l).SingleOrDefault();

            return View(d);
       

        }
    }
}